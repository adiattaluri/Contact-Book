import { Component, OnInit } from '@angular/core';
import { Contact } from '../contacts';
import { CONTACTS } from '../mock-contacts';

@Component({
  selector: 'app-people',
  templateUrl: './people.component.html',
  styleUrls: ['./people.component.scss']
})

export class PeopleComponent implements OnInit {

  public contacts = CONTACTS;
  public selectedContact: Contact;
  public contact: Contact = new Contact({});
  public index: number;
  public show : boolean= false;
  public add: boolean = false;

  constructor() { }

  onHome() {
    this.selectedContact=undefined;
    this.show=false;
    this.add=false;
  }
  ngOnInit() {
  }

  onSelect(contact: Contact): void {
    this.add =false;
    this.show=false;
    this.selectedContact = contact;
  }

  onDelete(contact: Contact): void {
      this.index=this.contacts.indexOf(contact);
      this.contacts.splice(this.index,1);
      this.selectedContact=undefined;
  }

  update(): void {
    this.add =false;
    this.show = ! this.show;
  }

  addContact(contact: Contact): void {
    let tempcontact: Contact= new Contact(this.contact);
    this.contacts.push(tempcontact);
    let temphero1: Contact= new Contact({});
    this.contact=temphero1;
    this.add = !this.add;
  }

  onAdd(): void {
    this.show = false;
    this.add = true;
    this.selectedContact= undefined;
    
  }

  cancel() {
    this.add=false;
    this.show=false;
  }
}
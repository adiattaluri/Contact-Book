import { Contact } from './contacts';
import { ChangeDetectorRef } from '@angular/core';

export let CONTACTS: Contact[] = [
  { id: 1,
    name: 'Chandermani Arora',
    email : 'chandermani.a@technovert.com',
    mobile: '+91 9292929292',
    landline: '040 30 1231211',
    website: 'http://www.technovert.com',
    address: '123 now heresome street Madhapur, Hyderabad 500033' },
  { id: 2,
    name: 'Sashi Pagadala',
    email : 'sashi.p@technovert.com',
    mobile: '+91 9292929292',
    landline: '040 30 1231211',
    website: 'http://www.technovert.com',
    address: '123 now here some street Madhapur, Hyderabad 500033' },
  { id: 3,
    name: 'Praveen Battula',
    email : 'praveen.b@technovert.com',
    mobile: '+91 9292929292',
    landline: '040 30 1231211',
    website: 'http://www.technovert.com',
    address: "123 now here some street Madhapur, Hyderabad 500033" },
  { id: 4,
    name: 'Vijay Yelamanchili',
    email : 'vijay.y@technovert.com',
    mobile: '+91 9292929292',
    landline: '040 30 1231211',
    website: 'http://www.technovert.com',
    address: '123 now heresome street Madhapur, Hyderabad 500033' }
];